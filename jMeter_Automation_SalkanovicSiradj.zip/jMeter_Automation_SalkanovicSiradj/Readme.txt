Usage:

1. Open jMeter
2. Open file GeocodingAPITest.jmx
3. Expand TestPlan
4. Expand Thread Group
5. Click on View Results Tree
6. Click on Start (Play button)
7. Two results appear: Geocoding and Reverse Geocoding
8. Click on either one, on the right you can select Request or Response data to see results

Note: your key parameter may be different from mine